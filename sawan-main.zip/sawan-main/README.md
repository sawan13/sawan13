<div>

# 👋 Hi there, I am <a href="https://sawan.dev">SAWAN MAKWANA!</a> <img align='right' src="https://github.com/sawan13/sawan/blob/main/github/cat.gif" height="" width="300" alt="coding cat">

</div>

<div>

![](https://img.shields.io/github/followers/SawanMakwana?label=follow&logo=github&style=flat-square)
![GitHub User's stars](https://img.shields.io/github/stars/SawanMakwana?label=%E2%AD%90GitHub%20stars&style=flat-square)
![](https://komarev.com/ghpvc/?username=SawanMakwana&style=flat-square&color=ff69b4)
<a href="https://discord.gg/az7Au3ZDGW">![Discord](https://img.shields.io/discord/686069011481362462?logo=discord&style=flat-square&label=web%20dev%20community)</a>

</div>

# <h1><a href="https://sawan.dev">sawan.dev</a> - Visit my portfolio</h1>

<p align="left">
<img src="https://github-readme-stats.vercel.app/api/top-langs?username=SawanMakwana&show_icons=true&locale=en&layout=compact&theme=radical" alt="most used languages" height=160 />
<img src="https://github-readme-stats.vercel.app/api?username=SawanMakwana&show_icons=true&theme=radical&layout=compact" alt="Sawan's Github Stats" height=160 />
<p>

***

## Technologies I have used

<table>
	<tr align="center">
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/python.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/ignition.png" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/iot.png" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/system_design.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/sql.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/postgresql.svg" width="60"/>
		</td>
	</tr>
	<tr align="center">
		<td>Python</td>
		<td>Ignition</td>
		<td>IoT</td>
		<td>System Design</td>
		<td>SQL</td>
		<td>PostgreSQL</td>
	</tr>
</table>
<table>
	<tr align="center">
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/kafka.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/grafana.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/powerbi.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/emqx.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/kepware.svg" width="60"/>
		</td>
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/html.svg" width="60"/>
		</td>
	</tr>
	<tr align="center">
		<td>Kafka</td>
		<td>Grafana</td>
		<td>Power BI</td>
		<td>EMQX</td>
		<td>Kepware</td>
		<td>HTML</td>
	</tr>
</table>
<table>
	<tr align="center">
		<td>
			<img src="https://github.com/sawan13/sawan/blob/main/github/icons/css.svg" width="60"/>
		</td>
	</tr>
	<tr align="center">
		<td>CSS</td>
	</tr>
</table>

---

## <img src="https://github.com/sawan13/sawan/blob/main/github/code.gif" width="32" align="left"> See my projects - [sawan.dev/projects](https://sawan.dev/projects)

## <img src="https://github.com/sawan13/sawan/blob/main/github/community.gif" width="48" align="left">&nbsp;&nbsp;Connect with me

<p align="left">
<a href="https://www.linkedin.com/in/sawanmakwana/"><img src="https://github.com/sawan13/sawan/blob/main/github/icons/linkedin.svg" width
